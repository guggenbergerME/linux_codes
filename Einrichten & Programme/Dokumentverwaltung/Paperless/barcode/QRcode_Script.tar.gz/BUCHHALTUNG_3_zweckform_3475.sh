#!/bin/bash

# Einstellungen
# Startnummer 1 - GLT
# Startnummer 2 - Elektro
# Startnummer 3 - Buchhaltung

start_num=253000000         # Startnummer für QR-Inhalte LAST 119
anzahl=144           # Anzahl der QR-Codes pro Blatt 144
prefix="ASN"       # Text vor der Nummer
output_dir="ausgeb/qrcodes"
labeled_dir="ausgabe/qrcodes_labeled"
pdf_output_dir="/home/pc813/Nextcloud/__ToDo/ARCHIV/QR-Code-Generator"  # NEU: Ausgabeordner für PDF

# Maße in mm
etikett_breite_mm=70
etikett_hoehe_mm=38
dpi=300
etikett_breite_px=$((etikett_breite_mm * dpi / 25))
etikett_hoehe_px=$((etikett_hoehe_mm * dpi / 25)) 
fontsize=52         # Schriftgröße

# Ordner vorbereiten
mkdir -p "$output_dir" "$labeled_dir" "$pdf_output_dir"
rm -f "$output_dir"/*.png "$labeled_dir"/*.png

# Fortlaufenden PDF-Dateinamen bestimmen
n=1
while :; do
    page_output=$(printf "%s/qr_codes_A4_%03d.pdf" "$pdf_output_dir" "$n")
    [[ -f $page_output ]] || break
    ((n++))
done

echo "🔄 Generiere GIMA Archiv QR-Codes mit Text darunter..."

for ((i=0; i<$anzahl; i++)); do
    num=$((start_num + i))
    code="${prefix}${num}"
    qr_file="$output_dir/${code}.png"
    labeled_file="$labeled_dir/${code}.png"

    # QR-Code erzeugen
    qrencode -o "$qr_file" -s 10 -l H "$code"

    # QR-Code auf Etikettengröße anpassen und Text hinzufügen
    convert "$qr_file" -resize x$((etikett_hoehe_px - 30)) \
        -gravity center -extent ${etikett_breite_px}x$((etikett_hoehe_px - 30)) \
        -background white miff:- | \
    convert - -gravity south -background white -splice 0x30 \
        -pointsize $fontsize -annotate +0+5 "$code" \
        -extent ${etikett_breite_px}x${etikett_hoehe_px} "$labeled_file"
done

echo "📄 Erzeuge DIN A4-Seite mit montierten QR-Codes auf cloud.gima-profi.info !"

# QR-Codes auf A4 montieren
montage "$labeled_dir"/*.png -tile 3x8 \
    -geometry +0+0 -page A4 "$page_output"

echo "✅ Fertig! Datei gespeichert unter: $page_output"
